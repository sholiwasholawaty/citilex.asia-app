"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { recordAttendance, getEmployees } from "@/src/actions/hrd";
import { Save, Calendar, ArrowLeft, Loader2 } from "lucide-react";
import Link from "next/link";
import { CustomSelect } from "@/src/components/ui/CustomSelect";

export default function NewAttendancePage() {
  const router = useRouter();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isCanceling, setIsCanceling] = useState(false);
  const [employees, setEmployees] = useState<any[]>([]);
  
  const [formData, setFormData] = useState({
    employeeId: "",
    date: new Date().toISOString().split("T")[0],
    checkInTime: "08:00",
    checkOutTime: "17:00",
    status: "PRESENT",
    notes: "",
  });

  useEffect(() => {
    getEmployees().then(setEmployees);
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      const dateObj = new Date(formData.date);
      let checkIn: Date | undefined;
      let checkOut: Date | undefined;

      if (formData.status === "PRESENT" || formData.status === "LATE") {
        const [inH, inM] = formData.checkInTime.split(":");
        checkIn = new Date(dateObj);
        checkIn.setHours(parseInt(inH), parseInt(inM));
        
        const [outH, outM] = formData.checkOutTime.split(":");
        checkOut = new Date(dateObj);
        checkOut.setHours(parseInt(outH), parseInt(outM));
      }

      await recordAttendance({
        employeeId: formData.employeeId,
        date: dateObj,
        checkIn,
        checkOut,
        status: formData.status,
        notes: formData.notes,
      });
      router.push("/app/hrd/attendance");
    } catch (error) {
      console.error(error);
      alert("Gagal menyimpan data absensi.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="flex flex-col h-full w-full bg-slate-50">
      <div className="bg-white border-b border-slate-200 px-8 py-8 shrink-0">
        <div className="max-w-3xl mx-auto">
          <button 
            type="button"
            onClick={() => { setIsCanceling(true); router.push('/app/hrd/attendance'); }}
            disabled={isCanceling}
            className="inline-flex items-center gap-2 text-sm text-slate-500 hover:text-slate-900 mb-4 transition-colors disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
          >
            {isCanceling ? <Loader2 className="w-4 h-4 animate-spin" /> : <ArrowLeft className="w-4 h-4" />} Back to Attendance & Leave
          </button>
          <h1 className="text-2xl font-bold text-slate-900 mb-2 flex items-center gap-2">
            <Calendar className="h-7 w-7 text-brand-gold" />
            Input Attendance / Leave
          </h1>
          <p className="text-slate-500 text-sm">
            Form ini digunakan oleh HRD untuk mencatat kehadiran atau jadwal cuti/izin pegawai.
          </p>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-8">
        <div className="max-w-3xl mx-auto h-full">
          <form onSubmit={handleSubmit} className="bg-white rounded-xl shadow-sm border border-slate-200 p-8 space-y-6">
            <div className="grid grid-cols-2 gap-6">
              
              <div className="col-span-2">
                <label className="block text-sm font-bold text-slate-700 mb-2">Pilih Pegawai</label>
                <CustomSelect 
                  value={formData.employeeId}
                  onChange={(val) => setFormData({...formData, employeeId: val})}
                  options={[
                    { value: "", label: "-- Pilih Pegawai --" },
                    ...employees.map(emp => ({ value: emp.id, label: `${emp.employeeId} - ${emp.name}` }))
                  ]}
                />
              </div>

              <div className="col-span-2 sm:col-span-1">
                <label className="block text-sm font-bold text-slate-700 mb-2">Tanggal</label>
                <input 
                  type="date" 
                  required
                  className="w-full p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-brand-gold focus:border-brand-gold transition-all"
                  value={formData.date}
                  onChange={(e) => setFormData({...formData, date: e.target.value})}
                />
              </div>

              <div className="col-span-2 sm:col-span-1">
                <label className="block text-sm font-bold text-slate-700 mb-2">Status Kehadiran</label>
                <CustomSelect 
                  value={formData.status}
                  onChange={(val) => setFormData({...formData, status: val})}
                  options={[
                    { value: "PRESENT", label: "Hadir" },
                    { value: "LATE", label: "Terlambat" },
                    { value: "SICK", label: "Sakit" },
                    { value: "LEAVE", label: "Izin / Cuti" },
                    { value: "ABSENT", label: "Alpa (Tanpa Keterangan)" }
                  ]}
                />
              </div>

              {(formData.status === "PRESENT" || formData.status === "LATE") && (
                <>
                  <div className="col-span-2 sm:col-span-1">
                    <label className="block text-sm font-bold text-slate-700 mb-2">Jam Masuk</label>
                    <input 
                      type="time" 
                      className="w-full p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-brand-gold focus:border-brand-gold transition-all"
                      value={formData.checkInTime}
                      onChange={(e) => setFormData({...formData, checkInTime: e.target.value})}
                    />
                  </div>
                  <div className="col-span-2 sm:col-span-1">
                    <label className="block text-sm font-bold text-slate-700 mb-2">Jam Keluar</label>
                    <input 
                      type="time" 
                      className="w-full p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-brand-gold focus:border-brand-gold transition-all"
                      value={formData.checkOutTime}
                      onChange={(e) => setFormData({...formData, checkOutTime: e.target.value})}
                    />
                  </div>
                </>
              )}

              <div className="col-span-2">
                <label className="block text-sm font-bold text-slate-700 mb-2">Keterangan (Opsional)</label>
                <textarea 
                  placeholder="Contoh: Surat sakit terlampir, cuti tahunan, dll"
                  className="w-full p-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-brand-gold focus:border-brand-gold transition-all"
                  value={formData.notes}
                  onChange={(e) => setFormData({...formData, notes: e.target.value})}
                />
              </div>
            </div>

            <div className="pt-6 border-t border-slate-100 flex justify-end gap-3">
              <button 
                type="button" 
                onClick={() => { setIsCanceling(true); router.push('/app/hrd/attendance'); }} 
                disabled={isSubmitting || isCanceling} 
                className="px-4 py-2 bg-white border border-slate-300 text-slate-600 hover:bg-slate-50 rounded-lg text-sm font-medium transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isCanceling ? <><Loader2 className="w-4 h-4 animate-spin" /> Membatalkan...</> : "Cancel"}
              </button>
              <button 
                type="submit" 
                disabled={isSubmitting || !formData.employeeId}
                className="px-4 py-2 bg-slate-800 text-white rounded-lg font-medium hover:bg-slate-900 transition-colors flex items-center justify-center gap-2 text-sm shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSubmitting ? <><Loader2 className="w-5 h-5 animate-spin" /> Menyimpan...</> : <><Save className="w-4 h-4 mr-2" /> Save</>}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
